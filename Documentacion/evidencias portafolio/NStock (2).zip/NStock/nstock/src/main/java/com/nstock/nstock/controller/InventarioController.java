package com.nstock.nstock.controller;

import com.nstock.nstock.entity.Inventario;
import com.nstock.nstock.repository.InventarioRepository;
import com.nstock.nstock.repository.ProductoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/inventario")
public class InventarioController {

    @Autowired
    private InventarioRepository inventarioRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @GetMapping
    public List<Map<String, Object>> listarInventarioConNombres() {
        // Traemos todo el inventario
        List<Inventario> lista = inventarioRepository.findAll();
        
        // Creamos una lista más "bonita" con nombres para el navegador
        return lista.stream().map(inv -> {
            Map<String, Object> map = new HashMap<>();
            map.put("idProducto", inv.getIdProducto());
            map.put("stockActual", inv.getStockActual());
            
            // Buscamos el nombre del producto para la tabla
            productoRepository.findById(inv.getIdProducto()).ifPresent(p -> {
                map.put("nombreProducto", p.getNombre());
            });
            
            return map;
        }).collect(Collectors.toList());
    }
}