package com.nstock.nstock.controller;

import com.nstock.nstock.entity.Producto;
import com.nstock.nstock.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    // Endpoint: GET http://localhost:8081/api/productos/buscar?codigo=12345
    @GetMapping("/buscar")
    public ResponseEntity<?> buscarProducto(@RequestParam String codigo) {
        try {
            Producto producto = productoService.buscarPorCodigo(codigo);
            return ResponseEntity.ok(producto);
        } catch (RuntimeException e) {
            // Si no existe, devolvemos un error 404 limpio
            return ResponseEntity.status(404).body("{\"error\": \"" + e.getMessage() + "\"}");
        }
    }
}