package com.nstock.nstock.service;

import com.nstock.nstock.entity.Producto;
import com.nstock.nstock.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    public Producto buscarPorCodigo(String codigoBarras) {
        Optional<Producto> producto = productoRepository.findByCodigoBarras(codigoBarras);
        
        if(producto.isPresent()){
            return producto.get();
        } else {
            throw new RuntimeException("Producto no encontrado");
        }
    }
}